#!/usr/bin/env bash
#   Use this script to test if a given TCP host/port are available

cmdname=$(basename $0)

echoerr() { if [[ $QUIET -ne 1 ]]; then echo "$@" 1>&2; fi }

usage()
{
    cat << USAGE >&2
Usage:
    $cmdname [-s seconds] [-- command args]
    -s SECONDS                  Wait for N seconds before starting command, default 15
    -- COMMAND ARGS             Execute command with args after the test finishes
USAGE
    exit 1
}

wait_for()
{
    if [[ $WAITSEC -gt 0 ]]; then
        echoerr "$cmdname: waiting $WAITSEC seconds"
        sleep $WAITSEC
    fi
    return 0
}


# process arguments
while [[ $# -gt 0 ]]
do
    case "$1" in
        -s)
        WAITSEC="$2"
        if [[ $WAITSEC == "" ]]; then break; fi
        shift 2
        ;;
        --)
        shift
        CLI=("$@")
        break
        ;;
        --help)
        usage
        ;;
        *)
        echoerr "Unknown argument: $1"
        usage
        ;;
    esac
done

WAITSEC=${WAITSEC:-15}

wait_for
RESULT=$?

if [[ $CLI != "" ]]; then
    exec "${CLI[@]}"
else
    exit $RESULT
fi
