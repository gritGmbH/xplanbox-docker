#!/usr/bin/env bash
#   Use this script to test if http urls are available

cmdname=$(basename $0)
cmdpath=$(dirname "${BASH_SOURCE[0]}")

echoerr() { if [[ $QUIET -ne 1 ]]; then echo "$@" 1>&2; fi }

usage()
{
    cat << USAGE >&2
Usage:
    $cmdname -u URL [-u URL ..] [-s] [-q] [-t timeout]  [-- command args]
    -s | --strict               Only execute subcommand if the test succeeds
    -q | --quiet                Don't output any status messages
    -u URL                      URL to test
    -t TIMEOUT | --timeout=TIMEOUT
                                Timeout in seconds, zero for no timeout
    -- COMMAND ARGS             Execute command with args after the test finishes
USAGE
    exit 1
}


wait_for()
{
    for URL in ${URLS[@]}
    do
        if [[ $TIMEOUT -gt 0 ]]; then
            echoerr "$cmdname: waiting $TIMEOUT seconds for $URL"
        else
            echoerr "$cmdname: waiting for $URL without a timeout"
        fi
        start_ts=$(date +%s)
        while :
        do
            curl --connect-timeout 15 -m 15 --silent --fail --show-error --fail -o /dev/null "$URL"
            result=$?
            
            end_ts=$(date +%s)
            if [[ $TIMEOUT -gt 0 && $((end_ts - start_ts)) -gt $TIMEOUT ]]; then
                echoerr " "
                echoerr "$cmdname: $URL is not available after $((end_ts - start_ts)) seconds, failing"
                result=2;
                break;
            fi
            if [[ $result -eq 0 ]]; then
                echoerr " "
                echoerr "$cmdname: $URL is available after $((end_ts - start_ts)) seconds"
                break
            fi
            echo -n "." 1>&2
            sleep 1
        done
    done
    return $result
}

declare -a URLS

# process arguments
while [[ $# -gt 0 ]]
do
    case "$1" in
        -q | --quiet)
        QUIET=1
        shift 1
        ;;
        -s | --strict)
        STRICT=1
        shift 1
        ;;
        -u)
        if [[ $2 == "" ]]; then break; fi
        URLS+=("$2")
        shift 2
        ;;
        -t)
        TIMEOUT="$2"
        if [[ $TIMEOUT == "" ]]; then break; fi
        shift 2
        ;;
        --timeout=*)
        TIMEOUT="${1#*=}"
        shift 1
        ;;
        --)
        shift
        CLI=("$@")
        break
        ;;
        --help)
        usage
        ;;
        *)
        echoerr "Unknown argument: $1"
        usage
        ;;
    esac
done

if [[ ${#URLS[@]} -eq 0 ]]; then
    echoerr "Error: you need to provide at least one URL to test."
    usage
fi

TIMEOUT=${TIMEOUT:-15}
STRICT=${STRICT:-0}
CHILD=${CHILD:-0}
QUIET=${QUIET:-0}

wait_for
RESULT=$?

if [[ $CLI != "" ]]; then
    if [[ $RESULT -ne 0 && $STRICT -eq 1 ]]; then
        echoerr "$cmdname: strict mode, refusing to execute subprocess"
        exit $RESULT
    fi
    exec "${CLI[@]}"
else
    exit $RESULT
fi
