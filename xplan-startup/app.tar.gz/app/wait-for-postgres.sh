#!/usr/bin/env bash
#   Use this script to test if postgres database(s) are available

cmdname=$(basename $0)
cmdpath=$(dirname "${BASH_SOURCE[0]}")

echoerr() { if [[ $QUIET -ne 1 ]]; then echo "$@" 1>&2; fi }

usage()
{
    cat << USAGE >&2
Usage:
    $cmdname -h host [-h host ..] [-s] [-q] [-t timeout] [-d DB] [-u USR] [-w PAS] [-- command args]
    -s | --strict               Only execute subcommand if the test succeeds
    -q | --quiet                Don't output any status messages
    -d DATABASE                 Database Name, defaults to postgres
    -p PORT                     Database Port, defualts to 5432
    -u USERNAME                 Database User, defaults to postgres
    -w PASSWORD                 Database Password, defaults to postgres
    -t TIMEOUT | --timeout=TIMEOUT
                                Timeout in seconds, zero for no timeout
    -- COMMAND ARGS             Execute command with args after the test finishes
USAGE
    exit 1
}


wait_for()
{
    for HOST in ${HOSTS[@]}
    do
        if [[ $TIMEOUT -gt 0 ]]; then
            echoerr "$cmdname: waiting $TIMEOUT seconds for $HOST"
        else
            echoerr "$cmdname: waiting for $HOST without a timeout"
        fi
        start_ts=$(date +%s)
        while :
        do
            java -jar $cmdpath/jdbc-tester-run.jar -t postgresql -h $HOST -p $DB_PORT -d $DATABASE -u $DB_USER -w $DB_PASS >>/${cmdname}.log 2>&1
            result=$?
            
            end_ts=$(date +%s)
            if [[ $TIMEOUT -gt 0 && $((end_ts - start_ts)) -gt $TIMEOUT ]]; then
                echoerr " "
                echoerr "$cmdname: $HOST is not available after $((end_ts - start_ts)) seconds, failing"
                result=2;
                break;
            fi
            if [[ $result -eq 0 ]]; then
                echoerr " "
                echoerr "$cmdname: $HOST is available after $((end_ts - start_ts)) seconds"
                break
            fi
            echo -n "." 1>&2
            sleep 1
        done
    done
    return $result
}

declare -a HOSTS

# process arguments
while [[ $# -gt 0 ]]
do
    case "$1" in
        -q | --quiet)
        QUIET=1
        shift 1
        ;;
        -s | --strict)
        STRICT=1
        shift 1
        ;;
        -h)
        if [[ $2 == "" ]]; then break; fi
        HOSTS+=("$2")
        shift 2
        ;;
        -d)
        if [[ $2 == "" ]]; then break; fi
        DATABASE="$2"
        shift 2
        ;;
        -u)
        if [[ $2 == "" ]]; then break; fi
        DB_USER="$2"
        shift 2
        ;;
        -w)
        if [[ $2 == "" ]]; then break; fi
        DB_PASS="$2"
        shift 2
        ;;
        -p)
        if [[ $2 == "" ]]; then break; fi
        DB_PORT="$2"
        shift 2
        ;;
        -t)
        TIMEOUT="$2"
        if [[ $TIMEOUT == "" ]]; then break; fi
        shift 2
        ;;
        --timeout=*)
        TIMEOUT="${1#*=}"
        shift 1
        ;;
        --)
        shift
        CLI=("$@")
        break
        ;;
        --help)
        usage
        ;;
        *)
        echoerr "Unknown argument: $1"
        usage
        ;;
    esac
done

if [[ ${#HOSTS[@]} -eq 0 ]]; then
    echoerr "Error: you need to provide at least one host to test."
    usage
fi

TIMEOUT=${TIMEOUT:-15}
STRICT=${STRICT:-0}
CHILD=${CHILD:-0}
QUIET=${QUIET:-0}
DATABASE=${DATABASE:-postgres}
DB_USER=${DB_USER:-postgres}
DB_PASS=${DB_PASS:-postgres}
DB_PORT=${DB_PORT:-5432}

wait_for
RESULT=$?

if [[ $CLI != "" ]]; then
    if [[ $RESULT -ne 0 && $STRICT -eq 1 ]]; then
        echoerr "$cmdname: strict mode, refusing to execute subprocess"
        exit $RESULT
    fi
    exec "${CLI[@]}"
else
    exit $RESULT
fi
